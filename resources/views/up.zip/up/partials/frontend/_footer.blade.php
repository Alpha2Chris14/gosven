<footer class="container-fluid p-0">
        <div>
            <div>
                <p>Subscribe To Newsletter</p>
                <p>sign up to get latest information from our farms
                and also promotion, discount deals
                </p>
            </div>
            <form action="/action_page.php" id="bottom-signup-form">
                <div class="input-group mb-3">
                    <input type="email" placeholder="ENTER EMAIL" name="" id="email-signup">
                    <div class="input-group-append">
                        <input type="submit" value="sign up" class="btn" id="email-signup-btn">
                    </div>
                </div>
            </form>
        </div>
        <div>
            <nav>
                <ul  id="bottom-nav-ul">
                    <div>
                        <li><a href="" class="bottom-link">Terms and conditions</a></li>
                        <li class="space-bottom-link"><a href="" class="bottom-link">Payments</a></li>
                        <li class="space-bottom-link"><a href="" class="bottom-link">Authenticity</a></li>
                    </div>
                    <div>
                        <li><a href="" class="bottom-link">Services</a></li>
                        <li class="space-bottom-link"><a href="" class="bottom-link">Payments</a></li>
                        <div class="visa-img">
                            <img src="/icons/Vector (1).svg" alt="">
                            <img src="/icons/visa.svg" alt="" srcset="">
                        </div>
                    </div>
                    <div>
                        <li><a href="" class="bottom-link">Privacy policy</a></li>
                        <li class="space-bottom-link"><a href="" class="bottom-link">Deliveries</a></li>
                        <li class="space-bottom-link"><a href="" class="bottom-link">About us</a></li>
                    </div>
                </ul>
            </nav>
                <img src="/icons/flutwave.svg" class="rounded mx-auto d-block" id="flutterwave-icon" alt="" srcset="">
            <div class="text-center">
                <hr class="bottom-hr"/>
                <p id="copyright-text"><small>Copyright &copy; 2020 govera.com. All rights reserved</small></p>
                <hr class="bottom-hr"/>
            </div>
        </div>
    </footer>