<div class="cart-container">
                        <a href="{{route('cart')}}">
                            <img src="/images/img_trans.gif" alt="cart" class="bg-cart_mobile"
                            width="1" height="1">
                            <span class="cart-value">{{count($carts)}}</span>
                        </a>
                    </div>